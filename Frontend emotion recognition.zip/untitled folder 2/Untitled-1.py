



import os
import numpy as np
from PIL import Image
import cv2
from flask import Flask, request, render_template
from werkzeug.utils import secure_filename
from tensorflow.keras.models import load_model


# Load the model using the correct Keras function
model = load_model('/Users/yogyachandna/Desktop/my_model.keras')
# Load your trained model



app = Flask(__name__)

print('Model loaded. Check http://127.0.0.1:5000/')

# Define the emotion class names (update these to match your model's training classes)
emotion_classes = ['Anger', 'Disgust', 'Fear', 'Happiness', 'Sadness', 'Surprise', 'Neutral']

def get_emotion_class(class_no):
    """
    Get the class name for the predicted emotion.
    """
    return emotion_classes[class_no]

def preprocess_image(img_path):
    """
    Preprocess the image to match the model's input requirements.
    """
    image = cv2.imread(img_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Convert BGR to RGB
    image = Image.fromarray(image)
    image = image.resize((48, 48))  # Resize to match the model input size
    image = np.array(image) / 255.0  # Normalize to [0, 1]
    input_img = np.expand_dims(image, axis=0)  # Add batch dimension
    return input_img

def predict_emotion(img_path):
    """
    Predict the emotion from the uploaded image.
    """
    input_img = preprocess_image(img_path)
    predictions = model.predict(input_img)
    predicted_class = np.argmax(predictions, axis=1)[0]
    return predicted_class, np.max(predictions)

@app.route('/', methods=['GET'])
def index():
    """
    Render the home page with the upload form.
    """
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def upload():
    """
    Handle image upload and return the prediction result.
    """
    if request.method == 'POST':
        f = request.files['file']
        
        # Save the uploaded file
        basepath = os.path.dirname(__file__)
        upload_folder = os.path.join(basepath, 'uploads')
        os.makedirs(upload_folder, exist_ok=True)
        file_path = os.path.join(upload_folder, secure_filename(f.filename))
        f.save(file_path)
        
        # Predict the emotion
        predicted_class, confidence = predict_emotion(file_path)
        result = f"{get_emotion_class(predicted_class)} with {confidence * 100:.2f}% confidence."
        return result

    return None

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
